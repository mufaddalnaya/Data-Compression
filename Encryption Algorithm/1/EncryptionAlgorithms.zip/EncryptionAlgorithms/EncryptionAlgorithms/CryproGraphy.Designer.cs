﻿namespace EncryptionAlgorithms
{
    partial class CryproGraphy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CryproGraphy));
            this.ribbonControl1 = new DevComponents.DotNetBar.RibbonControl();
            this.ribbonPanel1 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar2 = new DevComponents.DotNetBar.RibbonBar();
            this.BtnAESEncryption = new DevComponents.DotNetBar.ButtonItem();
            this.BtnAESDecryption = new DevComponents.DotNetBar.ButtonItem();
            this.BtnAESSettings = new DevComponents.DotNetBar.ButtonItem();
            this.groupPanel1 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.labelX1 = new DevComponents.DotNetBar.LabelX();
            this.Txtkey = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.ribbonBar1 = new DevComponents.DotNetBar.RibbonBar();
            this.BtnRC4Encryption = new DevComponents.DotNetBar.ButtonItem();
            this.BtnRC4Decryption = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel2 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar4 = new DevComponents.DotNetBar.RibbonBar();
            this.BtnRSAEncryption = new DevComponents.DotNetBar.ButtonItem();
            this.BtnRSADecryption = new DevComponents.DotNetBar.ButtonItem();
            this.BtnKeyPair = new DevComponents.DotNetBar.ButtonItem();
            this.RTItem1 = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItem2 = new DevComponents.DotNetBar.RibbonTabItem();
            this.office2007StartButton1 = new DevComponents.DotNetBar.Office2007StartButton();
            this.itemContainer1 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer2 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer3 = new DevComponents.DotNetBar.ItemContainer();
            this.BtnNew = new DevComponents.DotNetBar.ButtonItem();
            this.BtnOpen = new DevComponents.DotNetBar.ButtonItem();
            this.BtnSave = new DevComponents.DotNetBar.ButtonItem();
            this.BtnSaveAs = new DevComponents.DotNetBar.ButtonItem();
            this.BtnPrint = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer4 = new DevComponents.DotNetBar.ItemContainer();
            this.BtnExit = new DevComponents.DotNetBar.ButtonItem();
            this.qatCustomizeItem1 = new DevComponents.DotNetBar.QatCustomizeItem();
            this.TxtCrypto = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.requiredFieldValidator1 = new DevComponents.DotNetBar.Validator.RequiredFieldValidator("Your error message here.");
            this.highlighter1 = new DevComponents.DotNetBar.Validator.Highlighter();
            this.ribbonBar3 = new DevComponents.DotNetBar.RibbonBar();
            this.BtnTripleDESEncryption = new DevComponents.DotNetBar.ButtonItem();
            this.BtnTripleDESDecryption = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonControl1.SuspendLayout();
            this.ribbonPanel1.SuspendLayout();
            this.groupPanel1.SuspendLayout();
            this.ribbonPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.CaptionVisible = true;
            this.ribbonControl1.Controls.Add(this.ribbonPanel1);
            this.ribbonControl1.Controls.Add(this.ribbonPanel2);
            this.ribbonControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.ribbonControl1.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.RTItem1,
            this.ribbonTabItem2});
            this.ribbonControl1.KeyTipsFont = new System.Drawing.Font("Tahoma", 7F);
            this.ribbonControl1.Location = new System.Drawing.Point(4, 1);
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.Padding = new System.Windows.Forms.Padding(0, 0, 0, 2);
            this.ribbonControl1.QuickToolbarItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.office2007StartButton1,
            this.qatCustomizeItem1});
            this.ribbonControl1.Size = new System.Drawing.Size(776, 154);
            this.ribbonControl1.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonControl1.TabGroupHeight = 14;
            this.ribbonControl1.TabIndex = 0;
            this.ribbonControl1.Text = "ribbonControl1";
            // 
            // ribbonPanel1
            // 
            this.ribbonPanel1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonPanel1.Controls.Add(this.ribbonBar3);
            this.ribbonPanel1.Controls.Add(this.ribbonBar2);
            this.ribbonPanel1.Controls.Add(this.groupPanel1);
            this.ribbonPanel1.Controls.Add(this.ribbonBar1);
            this.ribbonPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel1.Location = new System.Drawing.Point(0, 55);
            this.ribbonPanel1.Name = "ribbonPanel1";
            this.ribbonPanel1.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel1.Size = new System.Drawing.Size(776, 97);
            this.ribbonPanel1.TabIndex = 1;
            // 
            // ribbonBar2
            // 
            this.ribbonBar2.AutoOverflowEnabled = true;
            this.ribbonBar2.ContainerControlProcessDialogKey = true;
            this.ribbonBar2.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar2.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.BtnAESEncryption,
            this.BtnAESDecryption,
            this.BtnAESSettings});
            this.ribbonBar2.Location = new System.Drawing.Point(148, 0);
            this.ribbonBar2.Name = "ribbonBar2";
            this.ribbonBar2.Size = new System.Drawing.Size(181, 94);
            this.ribbonBar2.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonBar2.TabIndex = 4;
            this.ribbonBar2.Text = "AES";
            // 
            // BtnAESEncryption
            // 
            this.BtnAESEncryption.Image = global::EncryptionAlgorithms.Properties.Resources.encrypted;
            this.BtnAESEncryption.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.BtnAESEncryption.Name = "BtnAESEncryption";
            this.BtnAESEncryption.SubItemsExpandWidth = 14;
            this.BtnAESEncryption.Text = "Encryption";
            this.BtnAESEncryption.Click += new System.EventHandler(this.BtnAESEncryption_Click);
            // 
            // BtnAESDecryption
            // 
            this.BtnAESDecryption.Image = global::EncryptionAlgorithms.Properties.Resources.decrypted;
            this.BtnAESDecryption.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.BtnAESDecryption.Name = "BtnAESDecryption";
            this.BtnAESDecryption.SubItemsExpandWidth = 14;
            this.BtnAESDecryption.Text = "Decryption";
            this.BtnAESDecryption.Click += new System.EventHandler(this.BtnAESDecryption_Click);
            // 
            // BtnAESSettings
            // 
            this.BtnAESSettings.Image = global::EncryptionAlgorithms.Properties.Resources.DataSettings;
            this.BtnAESSettings.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.BtnAESSettings.Name = "BtnAESSettings";
            this.BtnAESSettings.SubItemsExpandWidth = 14;
            this.BtnAESSettings.Text = "Settings";
            this.BtnAESSettings.Click += new System.EventHandler(this.BtnAESSettings_Click);
            // 
            // groupPanel1
            // 
            this.groupPanel1.BackColor = System.Drawing.Color.Transparent;
            this.groupPanel1.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel1.Controls.Add(this.labelX1);
            this.groupPanel1.Controls.Add(this.Txtkey);
            this.groupPanel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupPanel1.Location = new System.Drawing.Point(573, 0);
            this.groupPanel1.Name = "groupPanel1";
            this.groupPanel1.Size = new System.Drawing.Size(200, 94);
            // 
            // 
            // 
            this.groupPanel1.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel1.Style.BackColorGradientAngle = 90;
            this.groupPanel1.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel1.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderBottomWidth = 1;
            this.groupPanel1.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel1.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderLeftWidth = 1;
            this.groupPanel1.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderRightWidth = 1;
            this.groupPanel1.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderTopWidth = 1;
            this.groupPanel1.Style.CornerDiameter = 4;
            this.groupPanel1.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel1.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel1.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel1.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            this.groupPanel1.TabIndex = 3;
            // 
            // labelX1
            // 
            this.labelX1.AutoSize = true;
            this.labelX1.BackColor = System.Drawing.Color.Transparent;
            this.labelX1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelX1.Location = new System.Drawing.Point(39, 13);
            this.labelX1.Name = "labelX1";
            this.labelX1.Size = new System.Drawing.Size(117, 17);
            this.labelX1.TabIndex = 1;
            this.labelX1.Text = "Key For Encryption";
            // 
            // Txtkey
            // 
            // 
            // 
            // 
            this.Txtkey.Border.Class = "TextBoxBorder";
            this.highlighter1.SetHighlightOnFocus(this.Txtkey, true);
            this.Txtkey.Location = new System.Drawing.Point(10, 42);
            this.Txtkey.MaxLength = 50;
            this.Txtkey.Name = "Txtkey";
            this.Txtkey.Size = new System.Drawing.Size(181, 20);
            this.Txtkey.TabIndex = 2;
            this.Txtkey.Text = "APTTech";
            // 
            // ribbonBar1
            // 
            this.ribbonBar1.AutoOverflowEnabled = true;
            this.ribbonBar1.ContainerControlProcessDialogKey = true;
            this.ribbonBar1.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar1.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.BtnRC4Encryption,
            this.BtnRC4Decryption});
            this.ribbonBar1.Location = new System.Drawing.Point(3, 0);
            this.ribbonBar1.Name = "ribbonBar1";
            this.ribbonBar1.Size = new System.Drawing.Size(145, 94);
            this.ribbonBar1.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonBar1.TabIndex = 0;
            this.ribbonBar1.Text = "RC4 Algorithm";
            // 
            // BtnRC4Encryption
            // 
            this.BtnRC4Encryption.Image = global::EncryptionAlgorithms.Properties.Resources.encrypted;
            this.BtnRC4Encryption.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.BtnRC4Encryption.Name = "BtnRC4Encryption";
            this.BtnRC4Encryption.SubItemsExpandWidth = 14;
            this.BtnRC4Encryption.Text = "Encryption";
            this.BtnRC4Encryption.Click += new System.EventHandler(this.BtnRC4Encryption_Click);
            // 
            // BtnRC4Decryption
            // 
            this.BtnRC4Decryption.Image = global::EncryptionAlgorithms.Properties.Resources.decrypted;
            this.BtnRC4Decryption.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.BtnRC4Decryption.Name = "BtnRC4Decryption";
            this.BtnRC4Decryption.SubItemsExpandWidth = 14;
            this.BtnRC4Decryption.Text = "Decryption";
            this.BtnRC4Decryption.Click += new System.EventHandler(this.BtnRC4Decryption_Click);
            // 
            // ribbonPanel2
            // 
            this.ribbonPanel2.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonPanel2.Controls.Add(this.ribbonBar4);
            this.ribbonPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel2.Location = new System.Drawing.Point(0, 55);
            this.ribbonPanel2.Name = "ribbonPanel2";
            this.ribbonPanel2.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel2.Size = new System.Drawing.Size(776, 97);
            this.ribbonPanel2.TabIndex = 2;
            this.ribbonPanel2.Visible = false;
            // 
            // ribbonBar4
            // 
            this.ribbonBar4.AutoOverflowEnabled = true;
            this.ribbonBar4.ContainerControlProcessDialogKey = true;
            this.ribbonBar4.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar4.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.BtnRSAEncryption,
            this.BtnRSADecryption,
            this.BtnKeyPair});
            this.ribbonBar4.Location = new System.Drawing.Point(3, 0);
            this.ribbonBar4.Name = "ribbonBar4";
            this.ribbonBar4.Size = new System.Drawing.Size(206, 94);
            this.ribbonBar4.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonBar4.TabIndex = 0;
            this.ribbonBar4.Text = "RSA Algorithm";
            // 
            // BtnRSAEncryption
            // 
            this.BtnRSAEncryption.Image = global::EncryptionAlgorithms.Properties.Resources._lock;
            this.BtnRSAEncryption.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.BtnRSAEncryption.Name = "BtnRSAEncryption";
            this.BtnRSAEncryption.SubItemsExpandWidth = 14;
            this.BtnRSAEncryption.Text = "Encryption";
            this.BtnRSAEncryption.Click += new System.EventHandler(this.BtnRSAEncryption_Click);
            // 
            // BtnRSADecryption
            // 
            this.BtnRSADecryption.Image = global::EncryptionAlgorithms.Properties.Resources.unlock;
            this.BtnRSADecryption.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.BtnRSADecryption.Name = "BtnRSADecryption";
            this.BtnRSADecryption.SubItemsExpandWidth = 14;
            this.BtnRSADecryption.Text = "Decryption";
            this.BtnRSADecryption.Click += new System.EventHandler(this.BtnRSADecryption_Click);
            // 
            // BtnKeyPair
            // 
            this.BtnKeyPair.Image = global::EncryptionAlgorithms.Properties.Resources.keypair;
            this.BtnKeyPair.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.BtnKeyPair.Name = "BtnKeyPair";
            this.BtnKeyPair.SubItemsExpandWidth = 14;
            this.BtnKeyPair.Text = "Key Pair Generation";
            this.BtnKeyPair.Click += new System.EventHandler(this.BtnKeyPair_Click);
            // 
            // RTItem1
            // 
            this.RTItem1.Checked = true;
            this.RTItem1.Name = "RTItem1";
            this.RTItem1.Panel = this.ribbonPanel1;
            this.RTItem1.Text = "Symmetric key";
            // 
            // ribbonTabItem2
            // 
            this.ribbonTabItem2.Name = "ribbonTabItem2";
            this.ribbonTabItem2.Panel = this.ribbonPanel2;
            this.ribbonTabItem2.Text = "Public key";
            // 
            // office2007StartButton1
            // 
            this.office2007StartButton1.AutoExpandOnClick = true;
            this.office2007StartButton1.CanCustomize = false;
            this.office2007StartButton1.HotTrackingStyle = DevComponents.DotNetBar.eHotTrackingStyle.Image;
            this.office2007StartButton1.Image = global::EncryptionAlgorithms.Properties.Resources.security;
            this.office2007StartButton1.ImagePaddingHorizontal = 2;
            this.office2007StartButton1.ImagePaddingVertical = 2;
            this.office2007StartButton1.Name = "office2007StartButton1";
            this.office2007StartButton1.ShowSubItems = false;
            this.office2007StartButton1.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer1});
            this.office2007StartButton1.Text = "&File";
            // 
            // itemContainer1
            // 
            // 
            // 
            // 
            this.itemContainer1.BackgroundStyle.Class = "RibbonFileMenuContainer";
            this.itemContainer1.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer1.Name = "itemContainer1";
            this.itemContainer1.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer2,
            this.itemContainer4});
            // 
            // itemContainer2
            // 
            // 
            // 
            // 
            this.itemContainer2.BackgroundStyle.Class = "RibbonFileMenuTwoColumnContainer";
            this.itemContainer2.ItemSpacing = 0;
            this.itemContainer2.Name = "itemContainer2";
            this.itemContainer2.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer3});
            // 
            // itemContainer3
            // 
            // 
            // 
            // 
            this.itemContainer3.BackgroundStyle.Class = "RibbonFileMenuColumnOneContainer";
            this.itemContainer3.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer3.MinimumSize = new System.Drawing.Size(120, 0);
            this.itemContainer3.Name = "itemContainer3";
            this.itemContainer3.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.BtnNew,
            this.BtnOpen,
            this.BtnSave,
            this.BtnSaveAs,
            this.BtnPrint});
            // 
            // BtnNew
            // 
            this.BtnNew.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.BtnNew.Image = ((System.Drawing.Image)(resources.GetObject("BtnNew.Image")));
            this.BtnNew.Name = "BtnNew";
            this.BtnNew.SubItemsExpandWidth = 24;
            this.BtnNew.Text = "&New";
            this.BtnNew.Click += new System.EventHandler(this.BtnNew_Click);
            // 
            // BtnOpen
            // 
            this.BtnOpen.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.BtnOpen.Image = ((System.Drawing.Image)(resources.GetObject("BtnOpen.Image")));
            this.BtnOpen.Name = "BtnOpen";
            this.BtnOpen.SubItemsExpandWidth = 24;
            this.BtnOpen.Text = "&Open...";
            this.BtnOpen.Click += new System.EventHandler(this.BtnOpen_Click);
            // 
            // BtnSave
            // 
            this.BtnSave.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.BtnSave.Image = ((System.Drawing.Image)(resources.GetObject("BtnSave.Image")));
            this.BtnSave.Name = "BtnSave";
            this.BtnSave.SubItemsExpandWidth = 24;
            this.BtnSave.Text = "&Save...";
            this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
            // 
            // BtnSaveAs
            // 
            this.BtnSaveAs.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.BtnSaveAs.Image = global::EncryptionAlgorithms.Properties.Resources.save;
            this.BtnSaveAs.Name = "BtnSaveAs";
            this.BtnSaveAs.SubItemsExpandWidth = 24;
            this.BtnSaveAs.Text = "Save&As...";
            this.BtnSaveAs.Click += new System.EventHandler(this.BtnSaveAs_Click);
            // 
            // BtnPrint
            // 
            this.BtnPrint.BeginGroup = true;
            this.BtnPrint.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.BtnPrint.Image = ((System.Drawing.Image)(resources.GetObject("BtnPrint.Image")));
            this.BtnPrint.Name = "BtnPrint";
            this.BtnPrint.SubItemsExpandWidth = 24;
            this.BtnPrint.Text = "&Print...";
            // 
            // itemContainer4
            // 
            // 
            // 
            // 
            this.itemContainer4.BackgroundStyle.Class = "RibbonFileMenuBottomContainer";
            this.itemContainer4.Name = "itemContainer4";
            this.itemContainer4.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.BtnExit});
            // 
            // BtnExit
            // 
            this.BtnExit.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.BtnExit.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.BtnExit.Image = ((System.Drawing.Image)(resources.GetObject("BtnExit.Image")));
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.SubItemsExpandWidth = 24;
            this.BtnExit.Text = "E&xit";
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // qatCustomizeItem1
            // 
            this.qatCustomizeItem1.Name = "qatCustomizeItem1";
            // 
            // TxtCrypto
            // 
            // 
            // 
            // 
            this.TxtCrypto.Border.Class = "TextBoxBorder";
            this.TxtCrypto.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TxtCrypto.Location = new System.Drawing.Point(4, 155);
            this.TxtCrypto.Multiline = true;
            this.TxtCrypto.Name = "TxtCrypto";
            this.TxtCrypto.Size = new System.Drawing.Size(776, 405);
            this.TxtCrypto.TabIndex = 1;
            // 
            // requiredFieldValidator1
            // 
            this.requiredFieldValidator1.ErrorMessage = "Your error message here.";
            this.requiredFieldValidator1.HighlightColor = DevComponents.DotNetBar.Validator.eHighlightColor.Red;
            // 
            // highlighter1
            // 
            this.highlighter1.ContainerControl = this;
            this.highlighter1.FocusHighlightColor = DevComponents.DotNetBar.Validator.eHighlightColor.Red;
            // 
            // ribbonBar3
            // 
            this.ribbonBar3.AutoOverflowEnabled = true;
            this.ribbonBar3.ContainerControlProcessDialogKey = true;
            this.ribbonBar3.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar3.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.BtnTripleDESEncryption,
            this.BtnTripleDESDecryption});
            this.ribbonBar3.Location = new System.Drawing.Point(329, 0);
            this.ribbonBar3.Name = "ribbonBar3";
            this.ribbonBar3.Size = new System.Drawing.Size(142, 94);
            this.ribbonBar3.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonBar3.TabIndex = 5;
            this.ribbonBar3.Text = "Triple DES";
            // 
            // BtnTripleDESEncryption
            // 
            this.BtnTripleDESEncryption.Image = global::EncryptionAlgorithms.Properties.Resources.encrypted;
            this.BtnTripleDESEncryption.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.BtnTripleDESEncryption.Name = "BtnTripleDESEncryption";
            this.BtnTripleDESEncryption.SubItemsExpandWidth = 14;
            this.BtnTripleDESEncryption.Text = "Encryption";
            this.BtnTripleDESEncryption.Click += new System.EventHandler(this.BtnTripleDESEncryption_Click);
            // 
            // BtnTripleDESDecryption
            // 
            this.BtnTripleDESDecryption.Image = global::EncryptionAlgorithms.Properties.Resources.decrypted;
            this.BtnTripleDESDecryption.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.BtnTripleDESDecryption.Name = "BtnTripleDESDecryption";
            this.BtnTripleDESDecryption.SubItemsExpandWidth = 14;
            this.BtnTripleDESDecryption.Text = "Decryption";
            this.BtnTripleDESDecryption.Click += new System.EventHandler(this.BtnTripleDESDecryption_Click);
            // 
            // CryproGraphy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 562);
            this.Controls.Add(this.TxtCrypto);
            this.Controls.Add(this.ribbonControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CryproGraphy";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Untitled";
            this.Load += new System.EventHandler(this.CryproGraphy_Load);
            this.ribbonControl1.ResumeLayout(false);
            this.ribbonControl1.PerformLayout();
            this.ribbonPanel1.ResumeLayout(false);
            this.groupPanel1.ResumeLayout(false);
            this.groupPanel1.PerformLayout();
            this.ribbonPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.RibbonControl ribbonControl1;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel1;
        private DevComponents.DotNetBar.RibbonBar ribbonBar1;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel2;
        private DevComponents.DotNetBar.RibbonTabItem RTItem1;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem2;
        private DevComponents.DotNetBar.Office2007StartButton office2007StartButton1;
        private DevComponents.DotNetBar.ItemContainer itemContainer1;
        private DevComponents.DotNetBar.ItemContainer itemContainer2;
        private DevComponents.DotNetBar.ItemContainer itemContainer3;
        private DevComponents.DotNetBar.ButtonItem BtnNew;
        private DevComponents.DotNetBar.ButtonItem BtnOpen;
        private DevComponents.DotNetBar.ButtonItem BtnSave;
        private DevComponents.DotNetBar.ButtonItem BtnPrint;
        private DevComponents.DotNetBar.ItemContainer itemContainer4;
        private DevComponents.DotNetBar.ButtonItem BtnExit;
        private DevComponents.DotNetBar.QatCustomizeItem qatCustomizeItem1;
        private DevComponents.DotNetBar.Controls.TextBoxX TxtCrypto;
        private DevComponents.DotNetBar.ButtonItem BtnSaveAs;
        private DevComponents.DotNetBar.ButtonItem BtnRC4Encryption;
        private DevComponents.DotNetBar.ButtonItem BtnRC4Decryption;
        private DevComponents.DotNetBar.LabelX labelX1;
        private DevComponents.DotNetBar.Validator.RequiredFieldValidator requiredFieldValidator1;
        private DevComponents.DotNetBar.Controls.TextBoxX Txtkey;
        private DevComponents.DotNetBar.Validator.Highlighter highlighter1;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel1;
        private DevComponents.DotNetBar.RibbonBar ribbonBar2;
        private DevComponents.DotNetBar.ButtonItem BtnAESEncryption;
        private DevComponents.DotNetBar.ButtonItem BtnAESDecryption;
        private DevComponents.DotNetBar.ButtonItem BtnAESSettings;
        private DevComponents.DotNetBar.RibbonBar ribbonBar4;
        private DevComponents.DotNetBar.ButtonItem BtnRSAEncryption;
        private DevComponents.DotNetBar.ButtonItem BtnRSADecryption;
        private DevComponents.DotNetBar.ButtonItem BtnKeyPair;
        private DevComponents.DotNetBar.RibbonBar ribbonBar3;
        private DevComponents.DotNetBar.ButtonItem BtnTripleDESEncryption;
        private DevComponents.DotNetBar.ButtonItem BtnTripleDESDecryption;
    }
}

