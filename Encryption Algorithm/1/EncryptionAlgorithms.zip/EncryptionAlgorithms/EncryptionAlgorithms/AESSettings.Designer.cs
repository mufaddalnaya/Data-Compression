﻿namespace EncryptionAlgorithms
{
    partial class AESSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelX1 = new DevComponents.DotNetBar.LabelX();
            this.labelX2 = new DevComponents.DotNetBar.LabelX();
            this.labelX3 = new DevComponents.DotNetBar.LabelX();
            this.labelX4 = new DevComponents.DotNetBar.LabelX();
            this.TxtSaltValue = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.CboHashAlgorithm = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.CboSHA1 = new DevComponents.Editors.ComboItem();
            this.CboMD5 = new DevComponents.Editors.ComboItem();
            this.IntPasswordIterations = new DevComponents.Editors.IntegerInput();
            this.BtnOk = new DevComponents.DotNetBar.ButtonX();
            this.CboKeySize = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.Cbo128 = new DevComponents.Editors.ComboItem();
            this.Cbo192 = new DevComponents.Editors.ComboItem();
            this.Cbo256 = new DevComponents.Editors.ComboItem();
            ((System.ComponentModel.ISupportInitialize)(this.IntPasswordIterations)).BeginInit();
            this.SuspendLayout();
            // 
            // labelX1
            // 
            this.labelX1.AutoSize = true;
            this.labelX1.Location = new System.Drawing.Point(47, 12);
            this.labelX1.Name = "labelX1";
            this.labelX1.Size = new System.Drawing.Size(62, 15);
            this.labelX1.TabIndex = 0;
            this.labelX1.Text = "Salt Value  :";
            // 
            // labelX2
            // 
            this.labelX2.AutoSize = true;
            this.labelX2.Location = new System.Drawing.Point(22, 41);
            this.labelX2.Name = "labelX2";
            this.labelX2.Size = new System.Drawing.Size(87, 15);
            this.labelX2.TabIndex = 0;
            this.labelX2.Text = "Hash Algorithm  :";
            // 
            // labelX3
            // 
            this.labelX3.AutoSize = true;
            this.labelX3.Location = new System.Drawing.Point(1, 70);
            this.labelX3.Name = "labelX3";
            this.labelX3.Size = new System.Drawing.Size(108, 15);
            this.labelX3.TabIndex = 0;
            this.labelX3.Text = "Password Iterations  :";
            // 
            // labelX4
            // 
            this.labelX4.AutoSize = true;
            this.labelX4.Location = new System.Drawing.Point(54, 99);
            this.labelX4.Name = "labelX4";
            this.labelX4.Size = new System.Drawing.Size(55, 15);
            this.labelX4.TabIndex = 0;
            this.labelX4.Text = "Key Size  :";
            // 
            // TxtSaltValue
            // 
            // 
            // 
            // 
            this.TxtSaltValue.Border.Class = "TextBoxBorder";
            this.TxtSaltValue.Location = new System.Drawing.Point(115, 11);
            this.TxtSaltValue.Name = "TxtSaltValue";
            this.TxtSaltValue.Size = new System.Drawing.Size(131, 20);
            this.TxtSaltValue.TabIndex = 0;
            this.TxtSaltValue.Text = "s1@anyvalue";
            // 
            // CboHashAlgorithm
            // 
            this.CboHashAlgorithm.DisplayMember = "Text";
            this.CboHashAlgorithm.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.CboHashAlgorithm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CboHashAlgorithm.FormattingEnabled = true;
            this.CboHashAlgorithm.ItemHeight = 14;
            this.CboHashAlgorithm.Items.AddRange(new object[] {
            this.CboSHA1,
            this.CboMD5});
            this.CboHashAlgorithm.Location = new System.Drawing.Point(115, 41);
            this.CboHashAlgorithm.Name = "CboHashAlgorithm";
            this.CboHashAlgorithm.Size = new System.Drawing.Size(131, 20);
            this.CboHashAlgorithm.TabIndex = 1;
            // 
            // CboSHA1
            // 
            this.CboSHA1.Text = "SHA1";
            // 
            // CboMD5
            // 
            this.CboMD5.Text = "MD5";
            // 
            // IntPasswordIterations
            // 
            this.IntPasswordIterations.AllowEmptyState = false;
            // 
            // 
            // 
            this.IntPasswordIterations.BackgroundStyle.Class = "DateTimeInputBackground";
            this.IntPasswordIterations.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.IntPasswordIterations.Location = new System.Drawing.Point(115, 70);
            this.IntPasswordIterations.MaxValue = 999;
            this.IntPasswordIterations.MinValue = 0;
            this.IntPasswordIterations.Name = "IntPasswordIterations";
            this.IntPasswordIterations.ShowUpDown = true;
            this.IntPasswordIterations.Size = new System.Drawing.Size(80, 20);
            this.IntPasswordIterations.TabIndex = 2;
            // 
            // BtnOk
            // 
            this.BtnOk.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.BtnOk.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.BtnOk.Location = new System.Drawing.Point(93, 126);
            this.BtnOk.Name = "BtnOk";
            this.BtnOk.Size = new System.Drawing.Size(61, 23);
            this.BtnOk.TabIndex = 4;
            this.BtnOk.Text = "OK";
            this.BtnOk.Click += new System.EventHandler(this.BtnOk_Click);
            // 
            // CboKeySize
            // 
            this.CboKeySize.DisplayMember = "Text";
            this.CboKeySize.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.CboKeySize.FormattingEnabled = true;
            this.CboKeySize.ItemHeight = 14;
            this.CboKeySize.Items.AddRange(new object[] {
            this.Cbo128,
            this.Cbo192,
            this.Cbo256});
            this.CboKeySize.Location = new System.Drawing.Point(115, 96);
            this.CboKeySize.Name = "CboKeySize";
            this.CboKeySize.Size = new System.Drawing.Size(131, 20);
            this.CboKeySize.TabIndex = 3;
            // 
            // Cbo128
            // 
            this.Cbo128.Text = "128";
            // 
            // Cbo192
            // 
            this.Cbo192.Text = "192";
            // 
            // Cbo256
            // 
            this.Cbo256.Text = "256";
            // 
            // AESSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(247, 157);
            this.Controls.Add(this.BtnOk);
            this.Controls.Add(this.IntPasswordIterations);
            this.Controls.Add(this.CboKeySize);
            this.Controls.Add(this.CboHashAlgorithm);
            this.Controls.Add(this.TxtSaltValue);
            this.Controls.Add(this.labelX4);
            this.Controls.Add(this.labelX3);
            this.Controls.Add(this.labelX2);
            this.Controls.Add(this.labelX1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AESSettings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AES Settings";
            this.Load += new System.EventHandler(this.AESSettings_Load);
            ((System.ComponentModel.ISupportInitialize)(this.IntPasswordIterations)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevComponents.DotNetBar.LabelX labelX1;
        private DevComponents.DotNetBar.LabelX labelX2;
        private DevComponents.DotNetBar.LabelX labelX3;
        private DevComponents.DotNetBar.LabelX labelX4;
        private DevComponents.DotNetBar.Controls.TextBoxX TxtSaltValue;
        private DevComponents.DotNetBar.Controls.ComboBoxEx CboHashAlgorithm;
        private DevComponents.Editors.IntegerInput IntPasswordIterations;
        private DevComponents.DotNetBar.ButtonX BtnOk;
        private DevComponents.DotNetBar.Controls.ComboBoxEx CboKeySize;
        private DevComponents.Editors.ComboItem CboSHA1;
        private DevComponents.Editors.ComboItem CboMD5;
        private DevComponents.Editors.ComboItem Cbo128;
        private DevComponents.Editors.ComboItem Cbo192;
        private DevComponents.Editors.ComboItem Cbo256;
    }
}