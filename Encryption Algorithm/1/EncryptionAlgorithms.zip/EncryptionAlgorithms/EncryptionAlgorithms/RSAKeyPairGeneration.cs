﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace EncryptionAlgorithms
{
    public partial class RSAKeyPairGeneration : DevComponents.DotNetBar.Office2007Form
    {
        public RSAKeyPairGeneration()
        {
            InitializeComponent();
        }

        SaveFileDialog saveFileDialog = new SaveFileDialog();
       


        private bool saveFile(string title, string filterString, string outputString)
        {
            saveFileDialog.Title = title;
            saveFileDialog.Filter = filterString;
            saveFileDialog.FileName = "";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    StreamWriter streamWriter = new StreamWriter(saveFileDialog.FileName, false);
                    if (outputString != null)
                    { streamWriter.Write(outputString); }
                    streamWriter.Close();
                    return true;
                }
                catch (Exception Ex)
                {
                    Console.WriteLine(Ex.Message);
                    return false;
                }
            }
            return false;
        }

        private void BtnGenerate_Click(object sender, EventArgs e)
        {
          try
           {
                RSACryptoServiceProvider RSAProvider = new RSACryptoServiceProvider(( Convert.ToInt32( 1024 ) ));
                string publicAndPrivateKeys = "<BitStrength>" + numericUpDown.Value.ToString() + "</BitStrength>" + RSAProvider.ToXmlString(true);
                string justPublicKey = "<BitStrength>" + numericUpDown.Value.ToString() + "</BitStrength>" + RSAProvider.ToXmlString(false);
                if (saveFile("Save Private Keys As", "Private Keys Document( *.kez )|*.kez", publicAndPrivateKeys))
                { while (!saveFile("Save Public Key As", "Public Key Document( *.pke )|*.pke", justPublicKey)) { ; } }
            }
           catch (Exception Ex) { MessageBox.Show(Ex.Message, "RSA Key Genetation"); }
        }
       }
}
