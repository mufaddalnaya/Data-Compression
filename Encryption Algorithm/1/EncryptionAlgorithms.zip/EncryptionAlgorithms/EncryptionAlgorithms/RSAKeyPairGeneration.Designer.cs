﻿namespace EncryptionAlgorithms
{
    partial class RSAKeyPairGeneration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.reflectionImage1 = new DevComponents.DotNetBar.Controls.ReflectionImage();
            this.BtnGenerate = new DevComponents.DotNetBar.ButtonX();
            this.numericUpDown = new DevComponents.Editors.IntegerInput();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // reflectionImage1
            // 
            // 
            // 
            // 
            this.reflectionImage1.BackgroundStyle.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.reflectionImage1.Image = global::EncryptionAlgorithms.Properties.Resources.keypair;
            this.reflectionImage1.Location = new System.Drawing.Point(2, 12);
            this.reflectionImage1.Name = "reflectionImage1";
            this.reflectionImage1.Size = new System.Drawing.Size(49, 70);
            this.reflectionImage1.TabIndex = 0;
            // 
            // BtnGenerate
            // 
            this.BtnGenerate.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.BtnGenerate.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.BtnGenerate.Location = new System.Drawing.Point(57, 63);
            this.BtnGenerate.Name = "BtnGenerate";
            this.BtnGenerate.Size = new System.Drawing.Size(85, 29);
            this.BtnGenerate.TabIndex = 1;
            this.BtnGenerate.Text = "Generate Keys";
            this.BtnGenerate.Click += new System.EventHandler(this.BtnGenerate_Click);
            // 
            // numericUpDown
            // 
            // 
            // 
            // 
            this.numericUpDown.BackgroundStyle.Class = "DateTimeInputBackground";
            this.numericUpDown.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.numericUpDown.Location = new System.Drawing.Point(57, 23);
            this.numericUpDown.MaxValue = 16384;
            this.numericUpDown.MinValue = 384;
            this.numericUpDown.Name = "numericUpDown";
            this.numericUpDown.ShowUpDown = true;
            this.numericUpDown.Size = new System.Drawing.Size(85, 20);
            this.numericUpDown.TabIndex = 2;
            this.numericUpDown.Value = 1024;
            // 
            // RSAKeyPairGeneration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(174, 104);
            this.Controls.Add(this.numericUpDown);
            this.Controls.Add(this.BtnGenerate);
            this.Controls.Add(this.reflectionImage1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "RSAKeyPairGeneration";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RSA Key Pair Generation";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.Controls.ReflectionImage reflectionImage1;
        private DevComponents.DotNetBar.ButtonX BtnGenerate;
        private DevComponents.Editors.IntegerInput numericUpDown;
    }
}