﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EncryptionAlgorithms
{
    public partial class AESSettings : DevComponents.DotNetBar.Office2007Form 
    {
        public AESSettings()
        {
            InitializeComponent();
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            CryproGraphy cry = new CryproGraphy();
            cry.hashAlgorithm = CboHashAlgorithm.Text;
            cry.saltValue = TxtSaltValue.Text;        // can be any string
            cry.passwordIterations = IntPasswordIterations.Value ; // can be any number
            cry.keySize =int .Parse( CboKeySize.Text);   
            Close ();
        }
        private void AESSettings_Load(object sender, EventArgs e)
        {
              CboHashAlgorithm.SelectedIndex = 0;
              IntPasswordIterations.Value = 23;
              CboKeySize.SelectedIndex = 0;
        }
    }
}
