﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Xml.Serialization;
using CryptoRC4;

namespace EncryptionAlgorithms
{
       public partial class CryproGraphy : DevComponents.DotNetBar.Office2007RibbonForm 

    {
        public delegate void FinishedProcessDelegate();
        public delegate void UpdateBitStrengthDelegate(int bitStrength);
        public delegate void UpdateTextDelegate(string inputText);
       String CurrentFileName="Untitled";
          
        public CryproGraphy()
        {
            InitializeComponent();
        }

        private void BtnNew_Click(object sender, EventArgs e)
        {
            TxtCrypto.Text = "";
            this.Text = "Untitled-Cryptography";
            CurrentFileName = "Untitled";
        }

        private void BtnOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.FileName = "";
            openFileDialog.Title = "Open Text File";
            openFileDialog.Filter = "Text Document( *.txt )|*.txt";
            string fileString = null;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                if (File.Exists(openFileDialog.FileName))
                {
                    StreamReader streamReader = new StreamReader(openFileDialog.FileName, true);
                    fileString = streamReader.ReadToEnd();
                    streamReader.Close();
                    TxtCrypto.Text = fileString;
                    CurrentFileName = openFileDialog.FileName;
                    this.Text = CurrentFileName + "-Cryptography";
                }
            }
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
         this.Close();
        }

        private void CryproGraphy_Load(object sender, EventArgs e)
        {
            CurrentFileName = "Untitled";
            this.Text = CurrentFileName + "-Cryptography";
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (Text.Equals("Untitled-Cryptography"))
            {
                saveFile();
            }
            else
            {
                try
                {
                    StreamWriter streamWriter = new StreamWriter(CurrentFileName);
                    streamWriter.Write(TxtCrypto.Text);
                    streamWriter.Flush();
                    streamWriter.Close();
                 }
                catch (Exception Ex)
                { MessageBox.Show("ERROR: \n" + Ex.Message); }
            }
        }



        private  bool saveFile()
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Title = "Save As";
            saveFileDialog.FileName = "*.txt";
            saveFileDialog.Filter = "Text Document( *.txt )|*.txt|All Files|*.*";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    StreamWriter streamWriter = new StreamWriter(saveFileDialog.FileName, false);
                    streamWriter.Write(TxtCrypto.Text);
                    streamWriter.Close();
                    CurrentFileName = saveFileDialog.FileName;
                    this.Text = CurrentFileName + "-Cryptography";
                    return true;
                }
                catch (Exception Ex)
                {
                    Console.WriteLine(Ex.Message);
                    return false;
                }
            }
            return false;
        }
        private void BtnSaveAs_Click(object sender, EventArgs e)
        {
            saveFile();
        }

        private void BtnRC4Encryption_Click(object sender, EventArgs e)
        {
            if (this.TxtCrypto.Text.ToString() != "")
            {
                MessageBox.Show("The Text is going to change!", "Warning message");
               
            }
            RC4Engine myRC4Engine = new RC4Engine();
            myRC4Engine.EncryptionKey = this.Txtkey.Text;
            myRC4Engine.InClearText = this.TxtCrypto.Text;
            myRC4Engine.Encrypt();
            this.TxtCrypto.Text = myRC4Engine.CryptedText;
         }

        private void BtnRC4Decryption_Click(object sender, EventArgs e)
        {
            if (this.TxtCrypto.Text.ToString() != "")
            {
                MessageBox.Show("The Text is going to change!", "Warning message");
            }
            RC4Engine myRC4Engine = new RC4Engine();
            myRC4Engine.EncryptionKey = this.Txtkey.Text;
            myRC4Engine.CryptedText = this.TxtCrypto.Text;
            myRC4Engine.Decrypt();
            this.TxtCrypto.Text = myRC4Engine.InClearText;
        }

       
       public string saltValue = "s@1tValue";        // can be any string
       public string hashAlgorithm = "SHA1";        // can be "MD5"
       public int passwordIterations = 2;          // can be any number
       public int keySize = 256;                  // can be 192 or 128
       string initVector = "@1B2c3D4e5F6g7H8";   // must be 16 bytes

       private void BtnAESEncryption_Click(object sender, EventArgs e)
        {
            string passPhrase = Txtkey.Text ;        // can be any string
            string plainText = TxtCrypto.Text;    // original plaintext

           string cipherText = AESEngine.Encrypt(plainText,
                                                        passPhrase,
                                                        saltValue,
                                                        hashAlgorithm,
                                                        passwordIterations,
                                                        initVector,
                                                        keySize);
           if (this.TxtCrypto.Text.ToString() != "")
           {
               MessageBox.Show("The Text is going to change!", "Warning message");
           }
           TxtCrypto.Text = cipherText;
        }

        private void BtnAESSettings_Click(object sender, EventArgs e)
        {
            AESSettings AesFrm = new AESSettings();
            AesFrm.ShowDialog();
        }

        private void BtnAESDecryption_Click(object sender, EventArgs e)
        {
            string plainText = "";
            plainText = AESEngine.Decrypt(TxtCrypto.Text ,
                                                    Txtkey.Text,
                                                    saltValue,
                                                    hashAlgorithm,
                                                    passwordIterations,
                                                    initVector,
                                                    keySize);
            if (this.TxtCrypto.Text.ToString() != "")
            {
                MessageBox.Show("The Text is going to change!", "Warning message");
            }
            TxtCrypto.Text = plainText;    
        }

        private void BtnKeyPair_Click(object sender, EventArgs e)
        {
            RSAKeyPairGeneration Rsapairgen = new RSAKeyPairGeneration();
            Rsapairgen.ShowDialog();
        }
        private void UpdateText(string inputText)
        { TxtCrypto.Text = inputText; }
        private void FinishedProcess()
        {

        }
		
        OpenFileDialog openFileDialog = new OpenFileDialog();
        private void BtnRSAEncryption_Click(object sender, EventArgs e)
        {
            if (TxtCrypto.Text.Length != 0)
            {
                openFileDialog.FileName = "";
                openFileDialog.Title = "Open Public Key File";
                openFileDialog.Filter = "Public Key Document( *.pke )|*.pke";
                string fileString = null;
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    if (File.Exists(openFileDialog.FileName))
                    {
                        StreamReader streamReader = new StreamReader(openFileDialog.FileName, true);
                        fileString = streamReader.ReadToEnd();
                        streamReader.Close();
                        if (fileString.Length >= TxtCrypto.MaxLength)
                        { MessageBox.Show("ERROR: \nThe file you are trying to open is too big for the text editor to display properly.\nPlease open a smaller document!\nOperation Aborted!"); }
                    }
                }
                if (fileString != null)
                {
                    FinishedProcessDelegate finishedProcessDelegate = new FinishedProcessDelegate(FinishedProcess);
                    UpdateTextDelegate updateTextDelegate = new UpdateTextDelegate(UpdateText);
                    string bitStrengthString = fileString.Substring(0, fileString.IndexOf("</BitStrength>") + 14);
                    fileString = fileString.Replace(bitStrengthString, "");
                    int bitStrength = Convert.ToInt32(bitStrengthString.Replace("<BitStrength>", "").Replace("</BitStrength>", ""));
                   // Point point = new Point((TxtCrypto.Size.Width / 2) - (panel.Size.Width / 2), (TxtCrypto.Size.Height / 2) - (panel.Size.Height / 2));
                    //panel.Location = point;
                   // panel.Visible = true;
                    this.Refresh();
                    //fileMenuItem.Enabled = false;
                    //editMenuItem.Enabled = false;
                    //formatMenuItem.Enabled = false;
                    //encryptionMenuItem.Enabled = false;
                    //helpMenuItem.Enabled = false;
                    if (fileString != null)
                    {
                        try
                        {
                            EncryptionThread encryptionThread = new EncryptionThread();
                            Thread encryptThread = new Thread(encryptionThread.Encrypt);
                            encryptThread.IsBackground = true;
                            encryptThread.Start(new Object[] { this, finishedProcessDelegate, updateTextDelegate, TxtCrypto .Text, bitStrength, fileString });
                        }
                        catch (CryptographicException CEx)
                        { MessageBox.Show("ERROR: \nOne of the following has occured.\nThe cryptographic service provider cannot be acquired.\nThe length of the text being encrypted is greater than the maximum allowed length.\nThe OAEP padding is not supported on this computer.\n" + "Exact error: " + CEx.Message); }
                        catch (Exception Ex)
                        { MessageBox.Show("ERROR: \n" + Ex.Message); }
                    }
                }
            }
            else
            { MessageBox.Show("ERROR: You Can Not Encrypt A NULL Value!!!"); }

        }

        private void BtnRSADecryption_Click(object sender, EventArgs e)
        {
            if (TxtCrypto.Text.Length != 0)
            {
                openFileDialog.FileName = "";
                openFileDialog.Title = "Open Private Key File";
                openFileDialog.Filter = "Private Key Document( *.kez )|*.kez";
                string fileString = null;
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    if (File.Exists(openFileDialog.FileName))
                    {
                        StreamReader streamReader = new StreamReader(openFileDialog.FileName, true);
                        fileString = streamReader.ReadToEnd();
                        streamReader.Close();
                        if (fileString.Length >= TxtCrypto.MaxLength)
                        { MessageBox.Show("ERROR: \nThe file you are trying to open is too big for the text editor to display properly.\nPlease open a smaller document!\nOperation Aborted!"); }
                    }
                }
                if (File.Exists(openFileDialog.FileName))
                {
                    string bitStrengthString = fileString.Substring(0, fileString.IndexOf("</BitStrength>") + 14);
                    fileString = fileString.Replace(bitStrengthString, "");
                    int bitStrength = Convert.ToInt32(bitStrengthString.Replace("<BitStrength>", "").Replace("</BitStrength>", ""));
                   // Point point = new Point((inputTextBox.Size.Width / 2) - (panel.Size.Width / 2), (inputTextBox.Size.Height / 2) - (panel.Size.Height / 2));
                   // panel.Location = point;
                    //panel.Visible = true;
                    this.Refresh();
                   // fileMenuItem.Enabled = false;
                   // editMenuItem.Enabled = false;
                   // formatMenuItem.Enabled = false;
                   // encryptionMenuItem.Enabled = false;
                   // helpMenuItem.Enabled = false;
                    string tempStorage = TxtCrypto.Text;
                    if (fileString != null)
                    {
                        FinishedProcessDelegate finishedProcessDelegate = new FinishedProcessDelegate(FinishedProcess);
                        UpdateTextDelegate updateTextDelegate = new UpdateTextDelegate(UpdateText);
                        try
                        {
                            EncryptionThread decryptionThread = new EncryptionThread();
                            Thread decryptThread = new Thread(decryptionThread.Decrypt);
                            decryptThread.IsBackground = true;
                            decryptThread.Start(new Object[] { this, finishedProcessDelegate, updateTextDelegate, TxtCrypto.Text, bitStrength, fileString });
                        }
                        catch (CryptographicException CEx)
                        { MessageBox.Show("ERROR: \nOne of the following has occured.\nThe cryptographic service provider cannot be acquired.\nThe length of the text being encrypted is greater than the maximum allowed length.\nThe OAEP padding is not supported on this computer.\n" + "Exact error: " + CEx.Message); }
                        catch (Exception Ex)
                        {
                            MessageBox.Show("ERROR:\n" + Ex.Message);
                           //TxtCrypto. SetText(tempStorage);
                        }
                    }
                }
            }
            else
            { MessageBox.Show("ERROR: You Can Not Decrypt A NULL Value!!!"); }
        }

        private void BtnTripleDESEncryption_Click(object sender, EventArgs e)
        {
            try
            {

                TripleDESEngine TripleDES = new TripleDESEngine();
                TxtCrypto.Text = TripleDES.EncryptString(TxtCrypto.Text, Txtkey.Text);
            }
            catch (Exception ex)
            { MessageBox.Show("ERROR: You Can Not ecrypt A NULL Value!!!"); }
        }

        private void BtnTripleDESDecryption_Click(object sender, EventArgs e)
        {

            try
            {

                TripleDESEngine TripleDES = new TripleDESEngine();
                TxtCrypto.Text = TripleDES.DecryptString(TxtCrypto.Text, Txtkey.Text);
            }
            catch (Exception ex)
            { MessageBox.Show("ERROR: You Can Not Decrypt A NULL Value!!!"); }
        }

      

     













             
    }
}
