﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DevComponents.DotNetBar;

namespace EncryptionAlgorithms
{
    public partial class Login : DevComponents.DotNetBar.Office2007Form 
    {
        public Login()
        {
            InitializeComponent();
        }

        private void BtnClose_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Close();
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            if (TxtUserName.Text == "admin" & TxtPassword.Text == "admin")
            {
                CryproGraphy Main = new CryproGraphy();
                Main.Show();
                Hide();
            }
        else
            {
            MessageBoxEx.Show("Invalid User Name Or Password", "Login", MessageBoxButtons.OK, MessageBoxIcon.Information);
            TxtUserName.Select();
            }
        }

       
    }
}
