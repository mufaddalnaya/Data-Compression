package com.tomclaw.huffman;

/**
 * Created by solkin on 15/05/16.
 */
public class TextUtils {
    public static boolean isEmpty(String name) {
        return name == null || name.isEmpty();
    }
}
