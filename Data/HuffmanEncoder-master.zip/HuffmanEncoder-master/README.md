# HuffmanEncoder

Java implementation of Huffman encoding and decoding using priority queues submitted as a class project for the course Advanced Data Structures COP5536 Spring 2017.
